var indexSectionsWithContent =
{
  0: "abcdefghilnoprst",
  1: "abcdfghilprst",
  2: "gps",
  3: "acdefginopst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Pages"
};

